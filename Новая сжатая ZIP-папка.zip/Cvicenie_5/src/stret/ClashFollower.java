package stret;

public interface ClashFollower {
	void upovedom();
}
