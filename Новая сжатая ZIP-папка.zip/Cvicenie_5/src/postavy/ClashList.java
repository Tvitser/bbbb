package postavy;
import java.util.*;

public interface ClashList {
	List<? extends Warrior> vyberBojovnikov();
}
