package postavy;

public interface Warrior {

}
