package uloha3;


public class Delenie1 {
	public static void main(String[] args) {
		System.out.println(Integer.parseInt(args[0]) / Integer.parseInt(args[1]));
	}
}
