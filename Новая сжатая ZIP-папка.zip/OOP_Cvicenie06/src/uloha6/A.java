package uloha6;


public class A {
	void m() throws MyException {
		/* ... */
	}
}
