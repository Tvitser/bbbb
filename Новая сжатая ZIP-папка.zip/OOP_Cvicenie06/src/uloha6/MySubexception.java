package uloha6;


public class MySubexception extends MyException {

}
