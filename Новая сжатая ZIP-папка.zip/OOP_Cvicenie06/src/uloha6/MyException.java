package uloha6;


public class MyException extends Exception {

}
