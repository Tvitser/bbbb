package Clash;

public interface ClashFollower {
	void upovedom();
}
