package Clash;

public class NotClearWarriorNumberException extends Exception {
}
