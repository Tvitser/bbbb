package postavy;
import java.util.*;

// Vzor Composite - rola Component

public interface ClashList {
	List<Rytier> vyberBojovnikov();
}
